import os
import base64
import json
import requests
import tarfile
from pathlib import Path
import boto3
from datetime import datetime, timezone
from botocore.exceptions import ClientError

# === Config ===

EDITIONS = [e.strip() for e in os.environ.get("EDITIONS", "").split(",") if e.strip()]
S3_BUCKET = os.environ["S3_BUCKET"]
S3_PREFIX = os.environ.get("S3_PREFIX", "maxmind/")
SECRET_ID = os.environ.get(
    "SECRET_ID", "MaxMindCredentials"
)  # name of the secret in Secrets Manager

TMP_DIR = Path("/tmp")
s3 = boto3.client("s3")
secrets = boto3.client("secretsmanager")


def get_maxmind_credentials():
    try:
        secret_response = secrets.get_secret_value(SecretId=SECRET_ID)
        secret = json.loads(secret_response["SecretString"])
        return secret["ACCOUNT_ID"], secret["LICENSE_KEY"]
    except Exception as e:
        print(f"Error fetching secret '{SECRET_ID}': {e}")
        raise


# === Helpers ===


def get_auth_headers(account_id, license_key):
    auth_str = f"{account_id}:{license_key}"
    return {"Authorization": "Basic " + base64.b64encode(auth_str.encode()).decode()}


def get_sha256_from_maxmind(edition, headers):
    url = f"https://download.maxmind.com/geoip/databases/{edition}/download?suffix=tar.gz.sha256"
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        print(f"{edition}: HTTP error {response.status_code}")
        print(f"Response body: {response.text}")
        response.raise_for_status()
    return response.text.strip().split()[0]


def download_archive(edition, headers):
    url = (
        f"https://download.maxmind.com/geoip/databases/{edition}/download?suffix=tar.gz"
    )
    archive_path = TMP_DIR / f"{edition}.tar.gz"
    TMP_DIR.mkdir(parents=True, exist_ok=True)

    response = requests.get(url, headers=headers, stream=True)
    if response.status_code != 200:
        print(f"{edition}: archive download failed ({response.status_code})")
        print(response.text)
        response.raise_for_status()

    with open(archive_path, "wb") as f:
        for chunk in response.iter_content(8192):
            f.write(chunk)
    return archive_path


def extract_mmdb(archive_path, edition):
    with tarfile.open(archive_path, "r:gz") as tar:
        for member in tar.getmembers():
            if member.name.endswith(".mmdb") and edition in member.name:
                tar.extract(member, path=TMP_DIR)
                return TMP_DIR / member.name
    raise Exception(f"No .mmdb file found in archive for {edition}")


def load_hashes_from_s3():
    try:
        obj = s3.get_object(Bucket=S3_BUCKET, Key=f"{S3_PREFIX}hashes.json")
        return json.loads(obj["Body"].read())
    except ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchKey":
            return {}
        raise


def save_hashes_to_s3(hashes):
    s3.put_object(
        Bucket=S3_BUCKET,
        Key=f"{S3_PREFIX}hashes.json",
        Body=json.dumps(hashes, indent=2).encode("utf-8"),
        ContentType="application/json",
    )


def upload_mmdb_to_s3(edition, mmdb_path):
    s3_key = f"{S3_PREFIX}{edition}.mmdb"
    s3.upload_file(str(mmdb_path), S3_BUCKET, s3_key)
    print(f"{edition}: .mmdb uploaded to s3://{S3_BUCKET}/{s3_key}")


# === Core ===


def main():
    account_id, license_key = get_maxmind_credentials()
    headers = get_auth_headers(account_id, license_key)

    hashes = load_hashes_from_s3()
    updated = []
    skipped = []

    for edition in EDITIONS:
        print(f"Checking {edition}...")
        try:
            remote_hash = get_sha256_from_maxmind(edition, headers)
        except Exception as e:
            print(f"{edition}: failed to fetch hash: {e}")
            continue

        local_hash_entry = hashes.get(edition, {})
        if isinstance(local_hash_entry, dict):
            local_hash = local_hash_entry.get("sha256")
        else:
            # старый формат — просто строка с sha256
            local_hash = local_hash_entry

        if remote_hash == local_hash:
            print(f"{edition}: up to date")
            skipped.append(edition)
            continue

        print(f"{edition}: update detected")
        try:
            archive_path = download_archive(edition, headers)
            mmdb_path = extract_mmdb(archive_path, edition)
            upload_mmdb_to_s3(edition, mmdb_path)
            hashes[edition] = {
                "sha256": remote_hash,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            updated.append(edition)
        except Exception as e:
            print(f"{edition}: update failed: {e}")

    if updated:
        save_hashes_to_s3(hashes)

    return updated, skipped


# === Lambda Entry Point ===


def lambda_handler(event, context):
    updated, skipped = main()
    if updated:
        body = f"Updated: {', '.join(updated)}. Skipped: {', '.join(skipped)}"
    else:
        body = f"All databases up to date: {', '.join(skipped)}"
    return {"statusCode": 200, "body": body}
